package ejercicio;

public class Suite extends Habitacion{
	private int metros, servicios;

	public Suite(int n, int numC, String e, int m, int ser) {
		super(n, numC, e);
		this.metros=m;
		this.servicios=ser;
	}

	public int getMetros() {
		return metros;
	}

	public void setMetros(int metros) {
		this.metros = metros;
	}

	public int getServicios() {
		return servicios;
	}

	public void setServicios(int servicios) {
		this.servicios = servicios;
	}
	
	
}
