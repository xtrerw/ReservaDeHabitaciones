package ejercicio;

public class Habitacion {
	private int num, numCamas;
	private String estado;
	
	public Habitacion(int n, int numC, String e) {
		this.num=n;
		this.numCamas=numC;
		this.estado=e;
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
	}

	public int getNumCamas() {
		return numCamas;
	}

	public void setNumCamas(int numCamas) {
		this.numCamas = numCamas;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}
	
}
