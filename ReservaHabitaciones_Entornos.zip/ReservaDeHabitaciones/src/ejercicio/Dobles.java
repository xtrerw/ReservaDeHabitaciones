package ejercicio;

public class Dobles extends Habitacion{
	private boolean minibar;
	
	public Dobles(int n, int numC, String e, boolean m) {
		super(n, numC, e);
		this.minibar=m;
	}

	public boolean isMinibar() {
		return minibar;
	}

	public void setMinibar(boolean minibar) {
		this.minibar = minibar;
	}
	
}
